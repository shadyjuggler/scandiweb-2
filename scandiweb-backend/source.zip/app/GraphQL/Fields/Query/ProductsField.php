<?php

namespace App\GraphQL\Fields\Query;

use GraphQL\Type\Definition\Type;
use App\GraphQL\Types\ProductType;
use App\Models\Product;

class ProductsField
{
    public static function config(): array
    {
        return [
            'type' => Type::listOf(new ProductType),
            'resolve' => fn() => (new Product())->all()
        ];
    }
}